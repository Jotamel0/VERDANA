# Halloween do Verdana

Site estático para GitHub Pages. Fuso dos horários: Brasília (UTC−03:00).

## Horários configurados

- Avaliações: a partir de 19h em 24/10/2026.
- Envio de fotos: até 21h em 24/10/2026.

## Antes de publicar

1. Crie o novo formulário Jotform para avaliações.
2. No arquivo `index.html`, preencha `RATING_FORM_ID` com o ID do novo formulário. O ID aparece na URL ou no código de incorporação.
3. Confira se o formulário de fotos e a tabela pública estão corretos.
4. Para um pódio real compartilhado, configure `ENTRIES_ENDPOINT` e `RATINGS_ENDPOINT` no `index.html` para um serviço seguro.

O endpoint de leitura deve responder com uma lista neste formato:

```json
[
  {
    "id": "id-da-foto",
    "name": "Nome da fantasia",
    "photoUrl": "https://...",
    "ratings": [5, 4, 3]
  }
]
```

O endpoint de avaliações recebe `{ "entryId": "id-da-foto", "stars": 1 }`. Não coloque uma chave de API Jotform no HTML público. O GitHub Pages publica arquivos estáticos; a tabela Jotform incorporada aparece na página, mas o iframe não entrega as linhas para o JavaScript calcular o pódio. Até a configuração dos endpoints, as estrelas da galeria são uma prévia local.

## Publicar no GitHub Pages

1. Crie um repositório GitHub e envie os arquivos desta pasta para a raiz: `index.html`, `.nojekyll` e `README.md`.
2. No repositório, abra **Settings → Pages**.
3. Em **Build and deployment**, selecione **Deploy from a branch**, escolha a branch `main` e a pasta `/(root)`, depois salve.
4. Aguarde o GitHub publicar o endereço mostrado nessa página de configuração.

## Arquivos

- `index.html`: página, estilos e lógica do cronômetro, formulários, galeria e pódio.
- `.nojekyll`: publica os arquivos sem processamento Jekyll.

